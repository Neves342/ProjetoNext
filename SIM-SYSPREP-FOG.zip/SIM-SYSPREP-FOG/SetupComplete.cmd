sc config FOGService start= auto
shutdown -t 0 -r